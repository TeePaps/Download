#!/bin/sh

#
#
#Global variable definition, please do not modify these settings
#

LOG_FILE="/var/log/EI-17454_script.log"


#Function definition

#
#Monitor log function
#
LOG_FILE_SIZE=104857600
log_output()
{
    echo "`date`: "$1"" >> ${LOG_FILE}
    log_size=`stat -c %s ${LOG_FILE}`

    #empty the log file once the size exceeds 100M
    if [ "$log_size" -gt "$LOG_FILE_SIZE" ]; then
        echo "" > ${LOG_FILE}        
    fi
}


check_java_process()
{

grepOp="`ps aux | grep java | wc -l`"

if [ $grepOp -eq 1 ] ; then
   echo $grepOp
   log_output " Java Process isn't running : Doing a startup for tomcat & logging forest output"
   ps aux --forest >> ${LOG_FILE}
   echo -e '\n\n\n'
   echo "Vmstat Output"
   vmstat -s >> ${LOG_FILE}
   sh /usr/local/tomcat/bin/startup.sh
fi

}

#
#Main function
# 



check_java_process
