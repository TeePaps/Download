#!/bin/sh

cp -f EI-17454_Script.sh /usr/local/sbin/EI-17454_Script.sh

chmod +x /usr/local/sbin/EI-17454_Script.sh


echo "*/1  * * * * root /usr/local/sbin/EI-17454_Script.sh" >> /etc/crontab

echo "installation success!"
