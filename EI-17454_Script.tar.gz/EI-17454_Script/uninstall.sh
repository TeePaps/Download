#!/bin/sh

rm  -f  /usr/local/sbin/EI-17454_Script.sh

sed -i "/EI-17454_Script.sh/d" /etc/crontab

echo "Uninstallation success!"
